// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xisp_stitcher.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XIsp_stitcher_CfgInitialize(XIsp_stitcher *InstancePtr, XIsp_stitcher_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XIsp_stitcher_Start(XIsp_stitcher *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XIsp_stitcher_IsDone(XIsp_stitcher *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XIsp_stitcher_IsIdle(XIsp_stitcher *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XIsp_stitcher_IsReady(XIsp_stitcher *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XIsp_stitcher_EnableAutoRestart(XIsp_stitcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XIsp_stitcher_DisableAutoRestart(XIsp_stitcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_AP_CTRL, 0);
}

void XIsp_stitcher_Set_sel(XIsp_stitcher *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_SEL_DATA, Data);
}

u32 XIsp_stitcher_Get_sel(XIsp_stitcher *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_SEL_DATA);
    return Data;
}

void XIsp_stitcher_Set_m_axi_in0(XIsp_stitcher *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN0_DATA, (u32)(Data));
    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN0_DATA + 4, (u32)(Data >> 32));
}

u64 XIsp_stitcher_Get_m_axi_in0(XIsp_stitcher *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN0_DATA);
    Data += (u64)XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN0_DATA + 4) << 32;
    return Data;
}

void XIsp_stitcher_Set_m_axi_in1(XIsp_stitcher *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN1_DATA, (u32)(Data));
    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN1_DATA + 4, (u32)(Data >> 32));
}

u64 XIsp_stitcher_Get_m_axi_in1(XIsp_stitcher *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN1_DATA);
    Data += (u64)XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_IN1_DATA + 4) << 32;
    return Data;
}

void XIsp_stitcher_Set_m_axi_mapxy(XIsp_stitcher *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_MAPXY_DATA, (u32)(Data));
    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_MAPXY_DATA + 4, (u32)(Data >> 32));
}

u64 XIsp_stitcher_Get_m_axi_mapxy(XIsp_stitcher *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_MAPXY_DATA);
    Data += (u64)XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_MAPXY_DATA + 4) << 32;
    return Data;
}

void XIsp_stitcher_Set_m_axi_out(XIsp_stitcher *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_OUT_DATA, (u32)(Data));
    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XIsp_stitcher_Get_m_axi_out(XIsp_stitcher *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_OUT_DATA);
    Data += (u64)XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_M_AXI_OUT_DATA + 4) << 32;
    return Data;
}

void XIsp_stitcher_InterruptGlobalEnable(XIsp_stitcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_GIE, 1);
}

void XIsp_stitcher_InterruptGlobalDisable(XIsp_stitcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_GIE, 0);
}

void XIsp_stitcher_InterruptEnable(XIsp_stitcher *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_IER);
    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_IER, Register | Mask);
}

void XIsp_stitcher_InterruptDisable(XIsp_stitcher *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_IER);
    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XIsp_stitcher_InterruptClear(XIsp_stitcher *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XIsp_stitcher_WriteReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_ISR, Mask);
}

u32 XIsp_stitcher_InterruptGetEnabled(XIsp_stitcher *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_IER);
}

u32 XIsp_stitcher_InterruptGetStatus(XIsp_stitcher *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XIsp_stitcher_ReadReg(InstancePtr->Control_BaseAddress, XISP_STITCHER_CONTROL_ADDR_ISR);
}

