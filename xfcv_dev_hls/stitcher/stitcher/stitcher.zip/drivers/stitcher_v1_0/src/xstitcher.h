// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSTITCHER_H
#define XSTITCHER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xstitcher_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
} XStitcher_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XStitcher;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XStitcher_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XStitcher_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XStitcher_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XStitcher_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XStitcher_Initialize(XStitcher *InstancePtr, UINTPTR BaseAddress);
XStitcher_Config* XStitcher_LookupConfig(UINTPTR BaseAddress);
#else
int XStitcher_Initialize(XStitcher *InstancePtr, u16 DeviceId);
XStitcher_Config* XStitcher_LookupConfig(u16 DeviceId);
#endif
int XStitcher_CfgInitialize(XStitcher *InstancePtr, XStitcher_Config *ConfigPtr);
#else
int XStitcher_Initialize(XStitcher *InstancePtr, const char* InstanceName);
int XStitcher_Release(XStitcher *InstancePtr);
#endif

void XStitcher_Start(XStitcher *InstancePtr);
u32 XStitcher_IsDone(XStitcher *InstancePtr);
u32 XStitcher_IsIdle(XStitcher *InstancePtr);
u32 XStitcher_IsReady(XStitcher *InstancePtr);
void XStitcher_EnableAutoRestart(XStitcher *InstancePtr);
void XStitcher_DisableAutoRestart(XStitcher *InstancePtr);

void XStitcher_Set_mapxy(XStitcher *InstancePtr, u64 Data);
u64 XStitcher_Get_mapxy(XStitcher *InstancePtr);

void XStitcher_InterruptGlobalEnable(XStitcher *InstancePtr);
void XStitcher_InterruptGlobalDisable(XStitcher *InstancePtr);
void XStitcher_InterruptEnable(XStitcher *InstancePtr, u32 Mask);
void XStitcher_InterruptDisable(XStitcher *InstancePtr, u32 Mask);
void XStitcher_InterruptClear(XStitcher *InstancePtr, u32 Mask);
u32 XStitcher_InterruptGetEnabled(XStitcher *InstancePtr);
u32 XStitcher_InterruptGetStatus(XStitcher *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
