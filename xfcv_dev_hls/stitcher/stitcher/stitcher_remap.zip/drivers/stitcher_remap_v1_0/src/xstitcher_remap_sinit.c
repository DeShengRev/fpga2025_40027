// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xstitcher_remap.h"

extern XStitcher_remap_Config XStitcher_remap_ConfigTable[];

#ifdef SDT
XStitcher_remap_Config *XStitcher_remap_LookupConfig(UINTPTR BaseAddress) {
	XStitcher_remap_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XStitcher_remap_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XStitcher_remap_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XStitcher_remap_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XStitcher_remap_Initialize(XStitcher_remap *InstancePtr, UINTPTR BaseAddress) {
	XStitcher_remap_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XStitcher_remap_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XStitcher_remap_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XStitcher_remap_Config *XStitcher_remap_LookupConfig(u16 DeviceId) {
	XStitcher_remap_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSTITCHER_REMAP_NUM_INSTANCES; Index++) {
		if (XStitcher_remap_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XStitcher_remap_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XStitcher_remap_Initialize(XStitcher_remap *InstancePtr, u16 DeviceId) {
	XStitcher_remap_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XStitcher_remap_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XStitcher_remap_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

