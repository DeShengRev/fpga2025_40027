// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSTITCHER_REMAP_H
#define XSTITCHER_REMAP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xstitcher_remap_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XStitcher_remap_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XStitcher_remap;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XStitcher_remap_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XStitcher_remap_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XStitcher_remap_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XStitcher_remap_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XStitcher_remap_Initialize(XStitcher_remap *InstancePtr, UINTPTR BaseAddress);
XStitcher_remap_Config* XStitcher_remap_LookupConfig(UINTPTR BaseAddress);
#else
int XStitcher_remap_Initialize(XStitcher_remap *InstancePtr, u16 DeviceId);
XStitcher_remap_Config* XStitcher_remap_LookupConfig(u16 DeviceId);
#endif
int XStitcher_remap_CfgInitialize(XStitcher_remap *InstancePtr, XStitcher_remap_Config *ConfigPtr);
#else
int XStitcher_remap_Initialize(XStitcher_remap *InstancePtr, const char* InstanceName);
int XStitcher_remap_Release(XStitcher_remap *InstancePtr);
#endif

void XStitcher_remap_Start(XStitcher_remap *InstancePtr);
u32 XStitcher_remap_IsDone(XStitcher_remap *InstancePtr);
u32 XStitcher_remap_IsIdle(XStitcher_remap *InstancePtr);
u32 XStitcher_remap_IsReady(XStitcher_remap *InstancePtr);
void XStitcher_remap_EnableAutoRestart(XStitcher_remap *InstancePtr);
void XStitcher_remap_DisableAutoRestart(XStitcher_remap *InstancePtr);


void XStitcher_remap_InterruptGlobalEnable(XStitcher_remap *InstancePtr);
void XStitcher_remap_InterruptGlobalDisable(XStitcher_remap *InstancePtr);
void XStitcher_remap_InterruptEnable(XStitcher_remap *InstancePtr, u32 Mask);
void XStitcher_remap_InterruptDisable(XStitcher_remap *InstancePtr, u32 Mask);
void XStitcher_remap_InterruptClear(XStitcher_remap *InstancePtr, u32 Mask);
u32 XStitcher_remap_InterruptGetEnabled(XStitcher_remap *InstancePtr);
u32 XStitcher_remap_InterruptGetStatus(XStitcher_remap *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
